from local_queries import valuation as _execute
def run(payload):
    try:
        return _execute(payload)
    except ValueError as error:
        message = str(error)
        code = message.split(":", 1)[0]
        if code not in ("DATA_AMBIGUOUS", "UNSUPPORTED_OPERATION", "DATA_INCOMPLETE"):
            code = "INVALID_INPUT"
        return {"error": {"code": code, "message": message[:300]}}
