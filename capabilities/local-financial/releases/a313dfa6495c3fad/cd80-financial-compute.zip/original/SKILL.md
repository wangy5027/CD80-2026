---
name: cd80-financial-compute
description: 基于授权完整结果比较财务或汇总龙虎榜。
---
先取得完整本地结果工件。输出必须说明单位；输入没有单位时明确写单位未知，禁止默认为元。子任务通过inputRefs传递真实文件，不把ID当作内容。调用cd80/cd80-financial-compute-tool，file必须填系统授权清单的sandboxPath或其文件名部分，通常为fileId.json；sample.json只是展示名称，绝不能据此拼接/input/sample.json，也不能猜测ID。财务先明确证券、指标、报告期和唯一版本；累计指标只作相同月日跨年比较，不推导单季。龙虎榜保留原因和方向，只按已核实有效ID去重，不能把营业部行数称机构数。拒绝未完整输入、冲突和未知有效性；不换源、不联网、不改单位。
