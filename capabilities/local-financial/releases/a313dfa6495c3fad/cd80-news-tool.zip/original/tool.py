from query import execute
from migration_common import result
def run(payload):
    args = payload["input"]
    raw = execute("news", {"input":dict(args,limit=20,offset=0),"responses":payload["responses"]})
    if "request" in raw: return raw
    data = raw["result"]
    out = result("akshare",args,data["records"],warnings=["仅当前来源缓存前20条匹配记录，不是历史新闻全集。"],as_of=data.get("as_of"))
    out.update(provider_source=data["provider_source"],cache=data["cache"])
    if data.get("warning"): out["warnings"].append({"code":"SOURCE_WARNING","message":data["warning"],"fields":[]})
    return {"result":out}
