---
name: cd80-close-valuation
description: 本地收盘与估值，按实际本地数据查询并说明覆盖限制。
---

实际调用精确依赖工具 cd80/cd80-close-valuation-tool。先确认证券/指标身份，歧义时澄清；不根据记忆补数。
核对工具返回的requested、effective_range、as_of、security_as_of、单位、分页和覆盖；缺失与零分开。只使用返回的原始名称和链接。
服务失败或数据冲突时停止依赖分析，不改用南财或其他来源。读取完成不表示市场数据完整。
仅历史收盘与已有股票估值，各源日期独立，不称实时；不补ETF/指数估值。
