def run(payload):
    return {"sum": payload["a"] + payload["b"]}
